<?php

class Services_Twilio_Rest_TaskRouter_Reservations extends Services_Twilio_TaskRouterListResource {

}
