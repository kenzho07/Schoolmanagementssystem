<!-- Footer -->
<footer class="main">
	&copy; 2016 <strong>PencilCrunch</strong>. 
    Developed by 
	<a href="http://marcosfermin.net" 
    	target="_blank">Marcos Fermin</a>
</footer>
